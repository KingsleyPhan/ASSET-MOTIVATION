package com.pts.motivation.common;

public class SessionParams {
		public static String SESSION_CMPN_CD = "SESSION_CMPN_CD";
		public static String SESSION_CMPN_NAME ="SESSION_CMPN_NAME";
		public static String SESSION_USER_ID = "SESSION_USER_ID"; 
		public static String SESSION_USER_NAME="SESSION_USER_NAME";
		public static String SESSION_USER_CD="SESSION_USER_CD";
		public static String SESSION_COUPON_CD="SESSION_COUPON_CD";
		
		public static String OBJECT_CD="YYYYMMddHHmmSS";
		public static String CD_FULL_DATE="YYYYMMdd";
		
		public static String  MESSAGE_NOTIFICATION = "NOTIFICATION";
		public static String  MESSAGE_ERROR="ERROR";
}
