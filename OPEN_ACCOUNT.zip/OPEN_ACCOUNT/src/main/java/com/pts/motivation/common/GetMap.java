package com.pts.motivation.common;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.pts.motivation.model.DEPARTMENT_S;

public class GetMap {
	public GetMap() {
		
	}
	
//	public Map<String, String> getMapCompany(List<COMPANY> lst){
//		Map<String, String> mp = new HashMap<String, String>();
//		mp.put("", "");
//		for (COMPANY company : lst) {
//			mp.put(company.getId(), company.getName());
//		}
//		return mp;
//	}
//	
//	public Map<String, String> getMapDepartment(List<DEPARTMENT_S> lst){
//		Map<String, String> mp = new HashMap<String, String>();
//		mp.put("", "");
//		for (DEPARTMENT_S dept : lst) {
//			mp.put(dept.getId().trim(), dept.getName());
//		}
//		return mp;
//	}
}
