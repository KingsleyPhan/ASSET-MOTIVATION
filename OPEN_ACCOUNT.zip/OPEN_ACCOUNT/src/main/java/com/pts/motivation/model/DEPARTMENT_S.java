package com.pts.motivation.model;

public class DEPARTMENT_S {
	private String id; 
	private String name; 
	private String cmpnCd;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCmpnCd() {
		return cmpnCd;
	}
	public void setCmpnCd(String cmpnCd) {
		this.cmpnCd = cmpnCd;
	}
	
	
	
}
