package com.pts.motivation.model;

public class USER {
	private String id; 
	private String usn; 
	private String cd; 
	private String fullName;
	private String pass; 
	private String cmpnCd;
	private String cmpnName;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getUsn() {
		return usn;
	}
	public void setUsn(String usn) {
		this.usn = usn;
	}
	public String getCd() {
		return cd;
	}
	public void setCd(String cd) {
		this.cd = cd;
	}
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	public String getCmpnCd() {
		return cmpnCd;
	}
	public void setCmpnCd(String cmpnCd) {
		this.cmpnCd = cmpnCd;
	}
	public String getCmpnName() {
		return cmpnName;
	}
	public void setCmpnName(String cmpnName) {
		this.cmpnName = cmpnName;
	}
	
	
}
