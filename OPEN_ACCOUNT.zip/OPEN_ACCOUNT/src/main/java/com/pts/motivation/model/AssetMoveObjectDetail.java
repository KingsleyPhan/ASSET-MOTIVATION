package com.pts.motivation.model;

public class AssetMoveObjectDetail extends ASSET {
	
	private String idMove;
	private String statusMove;
	private String assesseries;
	private String status2;
	private String status;
	private String price;
	

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public String getIdMove() {
		return idMove;
	}

	public void setIdMove(String idMove) {
		this.idMove = idMove;
	}

	public String getStatusMove() {
		return statusMove;
	}

	public void setStatusMove(String statusMove) {
		this.statusMove = statusMove;
	}

	public String getAssesseries() {
		return assesseries;
	}

	public void setAssesseries(String assesseries) {
		this.assesseries = assesseries;
	}

	public String getStatus2() {
		return status2;
	}

	public void setStatus2(String status2) {
		this.status2 = status2;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
	
	
	
	
	
}
