package com.pts.motivation.model;

public class BaoCaoNoiBoDetail {
	private String deptCd; 
	private String deptName; 
	private String groupCd; 
	private String groupName;
	private String model;
	private String name; 
	private String sl;
	private String cmpnCd;
	
	public String getDeptCd() {
		return deptCd;
	}
	public void setDeptCd(String deptCd) {
		this.deptCd = deptCd;
	}
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	public String getGroupCd() {
		return groupCd;
	}
	public void setGroupCd(String groupCd) {
		this.groupCd = groupCd;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSl() {
		return sl;
	}
	public void setSl(String sl) {
		this.sl = sl;
	}
	public String getCmpnCd() {
		return cmpnCd;
	}
	public void setCmpnCd(String cmpnCd) {
		this.cmpnCd = cmpnCd;
	}
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	
	
}
