package com.pts.motivation.model;

public class Department {
	
	private String company_cd;
	public String getCompany_cd() {
		return company_cd;
	}
	public void setCompany_cd(String company_cd) {
		this.company_cd = company_cd;
	}
	private String dept_cd;
	public String getDept_cd() {
		return dept_cd;
	}
	public void setDept_cd(String dept_cd) {
		this.dept_cd = dept_cd;
	}
	public String getDept_name() {
		return dept_name;
	}
	public void setDept_name(String dept_name) {
		this.dept_name = dept_name;
	}
	private String dept_name;
	
	private String dept_desciption;
	public String getDept_desciption() {
		return dept_desciption;
	}
	public void setDept_desciption(String dept_desciption) {
		this.dept_desciption = dept_desciption;
	}
	

}
